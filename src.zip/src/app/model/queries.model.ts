export class Queries {

    id: number;
  
  }
  